package com.example.fonebook.controller;

import com.example.fonebook.dto.ContactDto;
import com.example.fonebook.service.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/contacts")
public class ContactController {
    @Autowired
    private ContactService contactService;

    public ResponseEntity<String> addContact(@RequestBody ContactDto contactDto) {
        try {
            contactService.addContact(contactDto);
            return ResponseEntity.ok("Contact added successfully");
        } catch (Exception e) {
            // Handle exceptions and return an appropriate error response
            return ResponseEntity.status(500).body("Error adding contact: " + e.getMessage());
        }
    }


}

