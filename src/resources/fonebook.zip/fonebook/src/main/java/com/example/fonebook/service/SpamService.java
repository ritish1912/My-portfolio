package com.example.fonebook.service;

import com.example.fonebook.repository.SpamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


public interface SpamService {

    boolean markNumberAsSpam(String userId, String phoneNumber);

    boolean hasUserMarkedSpam(String userId, String phoneNumber);

    public int getSpamLikelihood(String phoneNumber);
}
