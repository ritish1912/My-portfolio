package com.example.fonebook.repository;

import com.example.fonebook.model.Contact;
import com.example.fonebook.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ContactRepository extends JpaRepository<Contact, Long> {
    List<Contact> findByUser(User user);

    List<Contact> findByPhoneNumber(String phoneNumber);
}
