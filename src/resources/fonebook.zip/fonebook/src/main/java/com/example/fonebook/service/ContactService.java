package com.example.fonebook.service;

import com.example.fonebook.dto.ContactDto;
import com.example.fonebook.repository.ContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


public interface ContactService {


    public void addContact(ContactDto contactDto);
}
