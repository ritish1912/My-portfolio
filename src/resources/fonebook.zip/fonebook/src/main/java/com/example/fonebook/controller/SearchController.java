package com.example.fonebook.controller;

import com.example.fonebook.dto.SearchResultDto;
import com.example.fonebook.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.security.core.Authentication;

import java.util.List;

@RestController
@RequestMapping("/search")
public class SearchController {

    @Autowired
    private SearchService searchService;

    @GetMapping("/byName")
    public ResponseEntity<Object> searchByName(@RequestParam String name, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not authenticated");
        }

        List<SearchResultDto> searchResults = searchService.searchByName(name);
        // Handle the response based on the search results
        // ...

        // For simplicity, returning the results. Replace with actual logic.
        return ResponseEntity.ok(searchResults);
    }

    @GetMapping("/byPhoneNumber")
    public ResponseEntity<Object> searchByPhoneNumber(@RequestParam String phoneNumber, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not authenticated");
        }

        List<SearchResultDto> searchResults = searchService.searchByPhoneNumber(phoneNumber);
        // Handle the response based on the search results
        // ...

        // For simplicity, returning the results. Replace with actual logic.
        return ResponseEntity.ok(searchResults);
    }
}
