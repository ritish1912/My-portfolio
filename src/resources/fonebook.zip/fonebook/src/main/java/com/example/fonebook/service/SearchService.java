package com.example.fonebook.service;

import com.example.fonebook.dto.SearchResultDto;
import com.example.fonebook.repository.ContactRepository;
import com.example.fonebook.repository.SpamRepository;
import com.example.fonebook.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;


public interface SearchService {


    public List<SearchResultDto> searchByName(String name);

    public List<SearchResultDto> searchByPhoneNumber(String phoneNumber);
}
