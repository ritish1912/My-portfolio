package com.example.fonebook.service;

import com.example.fonebook.dto.ContactDto;
import com.example.fonebook.dto.UserRegistrationDto;
import com.example.fonebook.model.User;
import org.springframework.stereotype.Service;

import java.util.Optional;


public interface UserService {
    void registerUser(UserRegistrationDto userDto);

    public void addContactToUser(User user, ContactDto contactDto);

    public User getUserByPhoneNumber(String phoneNumber);

    User authenticateUser(String phoneNumber, String password);
}
