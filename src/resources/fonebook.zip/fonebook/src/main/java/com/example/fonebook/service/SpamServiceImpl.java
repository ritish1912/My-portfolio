package com.example.fonebook.service;

import com.example.fonebook.model.Spam;
import com.example.fonebook.repository.SpamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SpamServiceImpl implements SpamService {

    @Autowired
    private SpamRepository spamRepository;

    @Override
    public boolean markNumberAsSpam(String userId, String phoneNumber) {
        // Check if the user has already marked this number as spam
        if (hasUserMarkedSpam(userId, phoneNumber)) {
            return false; // Already marked as spam by the user
        }

        Spam newSpam = new Spam();
        newSpam.setPhoneNumber(phoneNumber);
        newSpam.setUserId(userId);

        // Save the spam information to the database
        spamRepository.save(newSpam);

        return true; // Successfully marked as spam
    }

    @Override
    public boolean hasUserMarkedSpam(String userId, String phoneNumber) {
        // Check if the user has already marked this number as spam
        return spamRepository.existsByUserIdAndPhoneNumber(userId, phoneNumber);
    }


    @Override
    public int getSpamLikelihood(String phoneNumber) {
            // Retrieve the spam information for the given phone number
            List<Spam> spamEntries = spamRepository.findByPhoneNumber(phoneNumber);

            // Return the spam likelihood if available, otherwise return 0
            return spamEntries.size();
        }
}
