package com.example.fonebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FonebookApplication {

	public static void main(String[] args) {
		SpringApplication.run(FonebookApplication.class, args);
	}

}
