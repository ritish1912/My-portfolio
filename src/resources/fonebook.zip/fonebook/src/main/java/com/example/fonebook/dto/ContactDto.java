package com.example.fonebook.dto;

import com.example.fonebook.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContactDto {
    private Long id;
    private String name;
    private String phoneNumber;
    private User user;
    private String userPhoneNumber;
}
