package com.example.fonebook.service;

import com.example.fonebook.dto.SearchResultDto;
import com.example.fonebook.model.Contact;
import com.example.fonebook.model.Spam;
import com.example.fonebook.model.User;
import com.example.fonebook.repository.ContactRepository;
import com.example.fonebook.repository.SpamRepository;
import com.example.fonebook.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SearchServiceImpl implements SearchService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ContactRepository contactRepository;

    @Autowired
    private SpamRepository spamRepository;

    @Autowired SpamService spamService;

    @Override
    public List<SearchResultDto> searchByName(String name) {
        // Search for users whose names start with or contain the specified name
        List<User> users = userRepository.findByNameStartingWithIgnoreCaseOrNameContainingIgnoreCase(name, name);

        // Create SearchResultDto objects for the search results
        return users.stream()
                .map(user -> createSearchResultDto(user, spamService.getSpamLikelihood(user.getPhoneNumber())))
                .collect(Collectors.toList());
    }

    @Override
    public List<SearchResultDto> searchByPhoneNumber(String phoneNumber) {
        // Search for a registered user with the specified phone number
        User registeredUser = userRepository.findByPhoneNumber(phoneNumber).orElse(null);

        if (registeredUser != null) {
            // If the user is registered, return a single SearchResultDto for that user
            return Collections.singletonList(createSearchResultDto(registeredUser, spamService.getSpamLikelihood(phoneNumber)));
        } else {
            // If the user is not registered, search for contacts with the specified phone number
            List<Contact> contacts = contactRepository.findByPhoneNumber(phoneNumber);

            // Create SearchResultDto objects for the search results
            return contacts.stream()
                    .map(contact -> createSearchResultDto(contact.getUser(), spamService.getSpamLikelihood(phoneNumber)))
                    .collect(Collectors.toList());
        }
    }

    private SearchResultDto createSearchResultDto(User user, int spamLikelihood) {
        // Create a SearchResultDto object for a user
        SearchResultDto resultDto = new SearchResultDto();
        resultDto.setName(user.getName());
        resultDto.setPhoneNumber(user.getPhoneNumber());
        resultDto.setSpamLikelihood(spamLikelihood);
        return resultDto;
    }
}

