package com.example.fonebook.controller;

import com.example.fonebook.config.JwtTokenProvider;
import com.example.fonebook.dto.UserLoginDto;
import com.example.fonebook.dto.UserRegistrationDto;
import com.example.fonebook.model.User;
import com.example.fonebook.service.SpamService;
import com.example.fonebook.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;


@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private SpamService spamService;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;




//    @PostMapping("/login")
//    public ResponseEntity<String> loginUser(@RequestBody UserLoginDto userDto) {
//        try {
//            // Authenticate user using userService
//            User authenticatedUser = userService.authenticateUser(userDto.getPhoneNumber(), userDto.getPassword());
//
//            // Generate JWT token
//            String token = jwtTokenProvider.GenerateToken(authenticatedUser.getPhoneNumber());
//
//            // Return the token in the response
//            return ResponseEntity.ok(token);
//        } catch (RuntimeException e) {
//            // Handle authentication error
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
//        }
//    }

    @PostMapping("/markSpam")
        public ResponseEntity<String> markSpam(@RequestParam String phoneNumber, Authentication authentication) {
        try {
            // Check if the user is authenticated
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not authenticated");
            }

            // Get the authenticated user's ID
            String userId = ((UserDetails) authentication.getPrincipal()).getUsername();

            // Mark the phone number as spam using userService
            boolean markedSuccessfully = spamService.markNumberAsSpam(userId, phoneNumber);

            if (markedSuccessfully) {
                // Return success response
                return ResponseEntity.ok("Number marked as spam successfully");
            } else {
                // Return error response if the number was already marked as spam by the user
                return ResponseEntity.badRequest().body("Number already marked as spam by the user");
            }
        } catch (RuntimeException e) {
            // Handle marking spam error
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }
}
