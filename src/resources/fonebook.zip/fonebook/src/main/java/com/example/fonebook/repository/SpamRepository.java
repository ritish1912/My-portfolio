package com.example.fonebook.repository;

import com.example.fonebook.model.Spam;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SpamRepository extends JpaRepository<Spam, Long> {
    List<Spam> findByPhoneNumber(String phoneNumber);

    boolean existsByUserIdAndPhoneNumber(String userId, String phoneNumber);
}
