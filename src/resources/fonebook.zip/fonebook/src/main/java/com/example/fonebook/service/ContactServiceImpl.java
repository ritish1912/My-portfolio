package com.example.fonebook.service;

import com.example.fonebook.dto.ContactDto;
import com.example.fonebook.model.Contact;
import com.example.fonebook.model.User;
import com.example.fonebook.repository.ContactRepository;
import com.example.fonebook.repository.UserRepository;
import io.micrometer.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContactServiceImpl implements ContactService{

    @Autowired
    private ContactRepository contactRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public void addContact(ContactDto contactDto) {
        // Validate if the contactDto has the required information
        if (contactDto == null || StringUtils.isBlank(contactDto.getName()) || StringUtils.isBlank(contactDto.getPhoneNumber())) {
            throw new RuntimeException("Invalid contact information");
        }

        // Check if the contact's phone number belongs to a registered user
        User user = userRepository.findByPhoneNumber(contactDto.getUserPhoneNumber()).orElse(null);
        if (user == null) {
            throw new RuntimeException("User with this phone number does not exist");
        }

        // Create a new Contact entity and save it to the database
        Contact newContact = new Contact();
        newContact.setName(contactDto.getName());
        newContact.setPhoneNumber(contactDto.getPhoneNumber());
        newContact.setUser(user);

        contactRepository.save(newContact);
    }
}