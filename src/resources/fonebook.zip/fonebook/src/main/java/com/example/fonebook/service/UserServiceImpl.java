package com.example.fonebook.service;

import com.example.fonebook.dto.ContactDto;
import com.example.fonebook.dto.UserRegistrationDto;
import com.example.fonebook.model.Contact;
import com.example.fonebook.model.Spam;
import com.example.fonebook.model.User;
import com.example.fonebook.repository.UserRepository;
import io.micrometer.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserServiceImpl implements  UserService{
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ContactService contactService;

    @Autowired
    private SpamService spamService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void registerUser(UserRegistrationDto userDto) {
        // Validate if the userDto has the required information
        if (userDto == null || StringUtils.isBlank(userDto.getName()) || StringUtils.isBlank(userDto.getPhoneNumber()) || StringUtils.isBlank(userDto.getPassword())) {
            throw new RuntimeException("Invalid user registration information");
        }

        // Check if a user with the same phone number already exists
        if (userRepository.findByPhoneNumber(userDto.getPhoneNumber()).isPresent()) {
            throw new RuntimeException("User with this phone number already exists");
        }

        // Create a new User entity and set the user information
        User newUser = new User();
        newUser.setName(userDto.getName());
        newUser.setPhoneNumber(userDto.getPhoneNumber());
        newUser.setEmail(userDto.getEmail());
        newUser.setPassword(passwordEncoder.encode(userDto.getPassword()));

        // Save the new user to the database
        userRepository.save(newUser);
    }

    @Override
    public void addContactToUser(User user, ContactDto contactDto) {
        // Validate if the contactDto has the required information
        if (contactDto == null || StringUtils.isBlank(contactDto.getName()) || StringUtils.isBlank(contactDto.getPhoneNumber())) {
            throw new RuntimeException("Invalid contact information");
        }

        // Check if the contact's phone number already exists for the user
        if (user.getContacts().stream().anyMatch(contact -> contact.getPhoneNumber().equals(contactDto.getPhoneNumber()))) {
            throw new RuntimeException("Contact with this phone number already exists for the user");
        }

        // Create a new Contact entity and add it to the user's contacts
        Contact newContact = new Contact();
        newContact.setName(contactDto.getName());
        newContact.setPhoneNumber(contactDto.getPhoneNumber());
        newContact.setUser(user);

        // Save the contact to the database
        contactService.addContact(contactDto);

        // Add the new contact to the user's contacts list
        user.getContacts().add(newContact);
        userRepository.save(user);
    }

    @Override
    public User getUserByPhoneNumber(String phoneNumber) {
        return userRepository.findByPhoneNumber(phoneNumber).orElse(null);
    }



    @Override
    public User authenticateUser(String phoneNumber, String password) {
        // Find the user by phone number
        User user = userRepository.findByPhoneNumber(phoneNumber).orElse(null);

        // Check if the user exists and the password is correct
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return user;
        } else {
            throw new RuntimeException("Invalid credentials");
        }
    }
}