package com.example.fonebook;


class FonebookApplicationTests {

	void contextLoads() {
	}

}
